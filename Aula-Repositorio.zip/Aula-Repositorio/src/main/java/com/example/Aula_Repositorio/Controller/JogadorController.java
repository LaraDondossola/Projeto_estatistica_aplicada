package com.example.Aula_Repositorio.Controller;

import com.example.Aula_Repositorio.Models.Jogador;
import com.example.Aula_Repositorio.Service.JogadorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jogadores")
public class JogadorController {

    private JogadorService jogadorService;

    public JogadorController(JogadorService jogadorService) {
        this.jogadorService = jogadorService;
    }

    @PostMapping
    public Jogador saveJogador(@RequestBody Jogador jogador) {
        return jogadorService.saveJogador(jogador.getNome(), jogador.getSobrenome());
    }

    @GetMapping
    public List<Jogador> getAllJogadores() {
        return jogadorService.getAllJogadores();
    }
}
