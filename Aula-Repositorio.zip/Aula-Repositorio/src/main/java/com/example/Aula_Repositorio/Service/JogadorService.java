package com.example.Aula_Repositorio.Service;

import com.example.Aula_Repositorio.Models.Jogador;
import com.example.Aula_Repositorio.Repositories.JogadorRepository;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class JogadorService {
    private JogadorRepository jogadorRepository;

    public JogadorService (JogadorRepository jogadorRepository){
        this.jogadorRepository = jogadorRepository;
    }
    public Jogador saveJogador(String nome, String sobrenome) {
        Jogador novoJogador = new Jogador();
        novoJogador.setNome(nome);
        novoJogador.setSobrenome(sobrenome);
        novoJogador.setClube("Criciuma");
        jogadorRepository.save(novoJogador);
        return novoJogador;


    }
    // Retorna todos os jogadores
    public List<Jogador> getAllJogadores() {
        return jogadorRepository.findAll();
    }
}
