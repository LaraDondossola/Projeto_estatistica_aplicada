package com.example.Aula_Repositorio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaRepositorioApplicationTests {

	@Test
	void contextLoads() {
	}

}
